package PROJELER.Proje3;

import utils.BaseStaticDriver;
/*
        Manual Create your account from the website

        Navigate to https://app.hubspot.com/login
        Enter the user name and password click on login button

        Click on Sales
        Click on Deals

        Click on Create Deal (Note: After clicking on the Deals in the automation not able to see the table just refresh the browser)
        Enter the Deal name

        Click on sales Pipeline (Verify second page URL is -->https://app.hubspot.com/pricing/7766931/sales?upgradeSource=deals-create-deal-general-create-deal-multiple-pipelines-pql-feature-lock&term=annual&edition=starter )
        Choose random from the Deal Stage dropdown
        Choose random from the Deal Type dropdown
        Click on Create button

        Click on the pen icon next to dollor amount on the left top
        Change the name
        And click on the save
        Verify name is changed

        Click on actions button
        Click on Delete
        Click on Delete deal

        Verify deal is not displayed any more



     */
public class Proje_Eng extends BaseStaticDriver {
    public static void main(String[] args) {


    }
}
